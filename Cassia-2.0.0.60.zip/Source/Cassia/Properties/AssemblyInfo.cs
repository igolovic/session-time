﻿using System.Reflection;

[assembly: AssemblyTitle("Cassia")]
